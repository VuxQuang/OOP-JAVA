package oop3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DtbDangNhap {
	protected static Connection conn = null;
	protected static final String DB_URL = "jdbc:mysql://localhost:3306/student_managenment";
	protected static final String username = "root";
	protected static final String password = "";

	public static Connection getConnection() {
		if (conn == null) {
			try {
				conn = DriverManager.getConnection(DB_URL, username, password);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return conn;
	}
}