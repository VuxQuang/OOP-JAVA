package oop3;

import oop3.NguoiDung;
import oop3.DtbDangNhap;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class NguoiDungDao extends DtbDangNhap {
	public NguoiDung dangnhap(String username, String password) {
		NguoiDung nd = null;
		Connection conn = null;
		 

		try {
			String sql = "select * from nguoidung where tennd=? and matkhau=? ";
			PreparedStatement pre = conn.prepareStatement(sql);
			pre.setString(1, username);
			pre.setString(2, password);
			ResultSet rs = pre.executeQuery();
			if (rs.next()) {
				nd = new NguoiDung();
				nd.setMand(rs.getString(1));
				nd.setTennd(rs.getString(2));
				nd.setMatkhau(rs.getString(3));
				nd.setVaitro(rs.getInt(4));
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return nd;
	}

public static Connection getConnection() {
    if (conn == null) {
        try {
			conn = DriverManager.getConnection(DB_URL, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    return conn;
}
}