package oop3;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import oop.StudentFrame;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DangNhap extends JFrame {

	private JPanel contentPane;
	private JTextField txtuser;
	private JPasswordField txtpassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DangNhap frame = new DangNhap();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DangNhap() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 552, 372);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("User Name");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel.setBounds(70, 51, 81, 44);
		contentPane.add(lblNewLabel);

		JLabel lblPassword = new JLabel("Password");
		lblPassword.setHorizontalAlignment(SwingConstants.CENTER);
		lblPassword.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblPassword.setBounds(70, 139, 81, 44);
		contentPane.add(lblPassword);

		JButton btnNewButton = new JButton("Đăng nhập");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NguoiDungDao nd = new NguoiDungDao();
				NguoiDung ndl = nd.dangnhap(txtuser.getText(), String.valueOf(txtpassword.getPassword()));
				if (ndl == null) {
					JOptionPane.showMessageDialog(null, "Nhập username/password không đúng");
				} else {
					JOptionPane.showMessageDialog(null, "Đăng nhập thành công");
					StudentFrame show = new StudentFrame();
					show.setVisible(true);
					this.dispose();

				}
			}

			private void dispose() {
				// TODO Auto-generated method stub

			}
		});
		btnNewButton.setBounds(224, 215, 89, 51);
		contentPane.add(btnNewButton);

		txtuser = new JTextField();
		txtuser.setBounds(210, 64, 143, 31);
		contentPane.add(txtuser);
		txtuser.setColumns(10);

		txtpassword = new JPasswordField();
		txtpassword.setBounds(210, 139, 143, 33);
		contentPane.add(txtpassword);
	}
}
