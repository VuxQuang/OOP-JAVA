package oop3;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnJDBC {
	public Connection getConnection(){
		Connection connection = null;
		try {
		connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_managenment", "root", "");
		if (connection != null) {
			System.out.println("Kết nối thành công");
		}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return connection;
	}
}
