package oop3;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import oop.StudentFrame;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DangNhapFrame extends JFrame {
	ConnJDBC cn = new ConnJDBC();
	Connection connection;
	private JPanel contentPane;
	private JTextField txtUser;
	private JTextField txtPwd;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DangNhapFrame frame = new DangNhapFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DangNhapFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 434, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtUser = new JTextField();
		txtUser.setBounds(127, 54, 264, 20);
		contentPane.add(txtUser);
		txtUser.setColumns(10);
		
		txtPwd = new JTextField();
		txtPwd.setColumns(10);
		txtPwd.setBounds(127, 113, 264, 20);
		contentPane.add(txtPwd);
		
		JLabel lblNewLabel = new JLabel("UserName\r\n");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(23, 49, 72, 31);
		contentPane.add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("PassWord");
		lblPassword.setHorizontalAlignment(SwingConstants.CENTER);
		lblPassword.setBounds(23, 108, 72, 31);
		contentPane.add(lblPassword);
		
		JButton btnNewButton = new JButton("Đăng Nhập");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dangnhap();
			}
		});
		btnNewButton.setBounds(144, 193, 140, 41);
		contentPane.add(btnNewButton);
	}
	private void dangnhap() {
		String tennd = txtUser.getText().toString().trim();
		String matkhau = txtPwd.getText().toString().trim();
		StringBuffer sb = new StringBuffer();
		if(tennd.equals("")) {
			sb.append("Mời nhập Username \n");
		}  
		if(matkhau.equals("")) {
			sb.append("Mời nhập PassWord\n");
		}
		if(sb.length()>0) {
			JOptionPane.showMessageDialog(this, sb.toString());
			return;
			
		}
		String sql_dangnhap = "Select * from nguoidung where tennd=? and matkhau=?";
		try {
			PreparedStatement pst = connection.prepareStatement(sql_dangnhap);
			pst.setString(1, tennd);
			pst.setString(2, matkhau);
			ResultSet rs = pst.executeQuery();
			if(rs.next()) {
				JOptionPane.showMessageDialog(this, "Đăng nhập thành công");
				new StudentFrame(tennd,matkhau).setVisible(true);
				this.setVisible(false);
			} else {
				JOptionPane.showMessageDialog(this, "Tài khoản hoặc mật khẩu không đúng");
			}
		} catch (Exception e) {
			
		}
	}
}
